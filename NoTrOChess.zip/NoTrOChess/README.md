# NoTrO chess
سازنده: امیرمهدی احمدی ملقب به نوترو
فقط همین فایل زیپ را داخل ریپوی GitHub آپلود کن، و فایل `.github/workflows/build.yml` را (از داخل زیپ) هم جدا در همان مسیر بگذار. اکشن خودش زیپ را باز می‌کند و APK می‌سازد (Artifacts → NoTrO-chess-apk).
