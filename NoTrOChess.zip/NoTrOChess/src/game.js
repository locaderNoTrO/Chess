'use strict';
/* NoTrO chess — creator: امیرمهدی احمدی ملقب به نوترو */
const $=s=>document.querySelector(s);
const TAU=Math.PI*2, PI=Math.PI;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const rnd=(a,b)=>a+Math.random()*(b-a);
const angDiff=(a,b)=>{let d=b-a;while(d>PI)d-=TAU;while(d<-PI)d+=TAU;return d;};
const nowS=()=>performance.now()/1000;
const fa=n=>{try{return Number(n).toLocaleString('fa-IR',{useGrouping:false});}catch(e){return String(n);}};
const ARENA=14.2;

/* ---------- save ---------- */
let save={level:1,color:'white',diff:2};
try{Object.assign(save,JSON.parse(localStorage.getItem('notro_chess')||'{}'));}catch(e){}
function persist(){try{localStorage.setItem('notro_chess',JSON.stringify(save));}catch(e){}}

/* ---------- data ---------- */
const DIFFS=[
 {name:'آب خوردن',em:'💧',ds:'اصلاً نمی‌تونن بهت آسیب بزنن. تفریحی!',hp:.35,dmg:.2,spd:.7,tele:1.7,cd:1.9,bot:0},
 {name:'آسون',em:'🌱',ds:'برای شروع و یادگیری',hp:.6,dmg:.5,spd:.85,tele:1.3,cd:1.35,bot:1},
 {name:'معمولی',em:'⚔️',ds:'تعادل واقعی بازی',hp:1,dmg:1,spd:1,tele:1,cd:1,bot:2},
 {name:'سخت',em:'🔥',ds:'ضربه‌ها قوی و سریع',hp:1.6,dmg:1.5,spd:1.2,tele:.8,cd:.75,bot:3},
 {name:'جهنمی',em:'😈',ds:'فقط برای حرفه‌ای‌ها',hp:2.4,dmg:2.3,spd:1.45,tele:.62,cd:.55,bot:4},
 {name:'آقا قلندری',em:'👁️‍🗨️',ds:'در حد خدا! هشدار: غیرممکن‌نما',hp:4.2,dmg:4,spd:1.9,tele:.4,cd:.3,bot:5}
];
const PIECES=['pawn','knight','bishop','rook','queen','king'];
const PN={pawn:'سرباز',knight:'اسب',bishop:'فیل',rook:'رخ',queen:'وزیر',king:'شاه'};
const GL={pawn:'♟',knight:'♞',bishop:'♝',rook:'♜',queen:'♛',king:'♚'};
function levelInfo(L){
 const boss=L%10===0;
 return {L,boss,final:L===1000,type:boss?'queen':PIECES[(L-1)%6],tier:(L-1)/6};
}
function enemyStats(info,D,type){
 type=type||info.type;const t=info.tier;
 const hp0={pawn:60,knight:80,bishop:80,rook:110,queen:130,king:200}[type];
 const dm0={pawn:14,knight:18,bishop:16,rook:22,queen:20,king:26}[type];
 let hp=hp0*(1+t*.03)*D.hp, dmg=dm0*(1+t*.012)*D.dmg;
 let spd=Math.min(3.2,(1+t*.006)*D.spd);
 let tele=Math.max(.2,D.tele/(1+t*.004));
 let cd=Math.max(.2,D.cd/(1+t*.004));
 if(info.boss&&type==='queen'){hp=hp0*3.4*(1+t*.03)*D.hp;dmg*=1.15;if(info.final){hp*=1.6;dmg*=1.2;}}
 return {hp,dmg,spd,tele,cd};
}

const cellX=i=>-14+i*4, cellZ=j=>-14+j*4;

/* ---------- audio (medieval / crusade-like, synthesized) ---------- */
let AC=null,NB=null,MASTER=null;
function audioInit(){try{if(!AC){const C=window.AudioContext||window.webkitAudioContext;if(C){AC=new C();MASTER=AC.createGain();MASTER.gain.value=.9;
 const cp=AC.createDynamicsCompressor();MASTER.connect(cp);cp.connect(AC.destination);
 const n=AC.sampleRate,b=AC.createBuffer(1,n,AC.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;NB=b;}}
 if(AC&&AC.state==='suspended')AC.resume();}catch(e){}}
function env(g,t,a,d,v){g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+a);g.gain.exponentialRampToValueAtTime(.0001,t+a+d);}
function osc(type,f,t,d,v,slide,dest,a){const o=AC.createOscillator(),g=AC.createGain();o.type=type;o.frequency.setValueAtTime(f,t);
 if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(20,slide),t+d);env(g,t,a||.004,d,v);o.connect(g);g.connect(dest||MASTER);o.start(t);o.stop(t+d+.05);return g;}
function nz(t,d,v,ftype,f0,f1,q,a){const s=AC.createBufferSource();s.buffer=NB;s.loop=true;const f=AC.createBiquadFilter();f.type=ftype;f.Q.value=q||1;
 f.frequency.setValueAtTime(f0,t);if(f1)f.frequency.exponentialRampToValueAtTime(f1,t+d);const g=AC.createGain();env(g,t,a||.005,d,v);
 s.connect(f);f.connect(g);g.connect(MASTER);s.start(t,Math.random());s.stop(t+d+.05);}
function clang(t,base,v,d){[1,2.76,5.4,8.93].forEach((m,i)=>osc(i%2?'sine':'triangle',base*m*(1+Math.random()*.01),t,(d||.5)/(1+i*.6),v/(1+i*1.1),0,null,.001));
 nz(t,.05,v*1.4,'bandpass',3500,2500,1.2,.001);}
function thud(t,f,v,d){osc('sine',f,t,d||.25,v,f*.45,null,.002);nz(t,.08,v*.6,'lowpass',500,200,1,.002);}
function grunt(t,f,v,d){const g=osc('sawtooth',f,t,d,v,f*.7,null,.02);const o=AC.createOscillator();}
function voice(t,f,v,d){const o=AC.createOscillator(),g=AC.createGain(),bp=AC.createBiquadFilter();o.type='sawtooth';o.frequency.setValueAtTime(f,t);
 o.frequency.exponentialRampToValueAtTime(f*.68,t+d);bp.type='bandpass';bp.frequency.value=650;bp.Q.value=2.5;env(g,t,.03,d,v);o.connect(bp);bp.connect(g);g.connect(MASTER);o.start(t);o.stop(t+d+.05);}
function horn(t,f,d,v){[1,1.5,2].forEach((m,i)=>{const o=AC.createOscillator(),g=AC.createGain(),lp=AC.createBiquadFilter();o.type='sawtooth';o.frequency.setValueAtTime(f*m*.97,t);
 o.frequency.linearRampToValueAtTime(f*m,t+.25);lp.type='lowpass';lp.frequency.setValueAtTime(250,t);lp.frequency.linearRampToValueAtTime(1100,t+d*.6);
 g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v/(i+1),t+.2);g.gain.setValueAtTime(v/(i+1),t+d-.3);g.gain.linearRampToValueAtTime(.0001,t+d);
 o.connect(lp);lp.connect(g);g.connect(MASTER);o.start(t);o.stop(t+d+.05);});}
function sfx(k){
 if(!AC)return;const t=AC.currentTime;
 try{switch(k){
  case 'swing':nz(t,.22,.22,'bandpass',500,2600,1.4,.04);break;
  case 'hit':nz(t,.12,.4,'lowpass',2200,300,.8,.002);thud(t,110,.35,.22);clang(t+.01,620,.1,.25);break;
  case 'hurt':thud(t,85,.45,.3);nz(t,.2,.3,'lowpass',1200,200,1,.002);voice(t+.02,190,.16,.3);break;
  case 'block':clang(t,780,.22,.55);thud(t,160,.35,.2);break;
  case 'step':thud(t,70+Math.random()*20,.11,.12);nz(t,.05,.05,'highpass',4000,5000,1,.001);break;
  case 'tele':nz(t,.35,.09,'bandpass',300,900,2,.15);break;
  case 'boom':thud(t,55,.7,.7);nz(t,.6,.5,'lowpass',900,80,1,.005);break;
  case 'beam':nz(t,.4,.3,'bandpass',4000,700,3,.01);osc('sawtooth',900,t,.4,.07,200);break;
  case 'land':thud(t,60,.6,.5);nz(t,.35,.4,'lowpass',700,90,1,.003);break;
  case 'die':voice(t,150,.25,.9);thud(t,60,.5,.6);break;
  case 'win':horn(t,196,1.6,.12);horn(t+.9,262,1.8,.12);break;
  case 'lose':horn(t,110,2.2,.14);break;
  case 'boss':horn(t,82,2.2,.2);thud(t,45,.7,1);break;
  case 'ui':clang(t,1500,.05,.12);break;
 }}catch(e){}
}
let ambTimer=null,ambStep=0,droneNodes=null;
function ambience(on){
 if(!AC)return;
 if(ambTimer){clearInterval(ambTimer);ambTimer=null;}
 if(droneNodes){try{droneNodes.g.gain.exponentialRampToValueAtTime(.0001,AC.currentTime+.8);droneNodes.o.forEach(o=>o.stop(AC.currentTime+1));}catch(e){}droneNodes=null;}
 if(!on)return;
 try{const g=AC.createGain(),lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=380;g.gain.value=.0001;g.gain.exponentialRampToValueAtTime(.05,AC.currentTime+2);
  const o=[110,164.8,110.7].map(f=>{const x=AC.createOscillator();x.type='sawtooth';x.frequency.value=f;x.connect(lp);x.start();return x;});
  lp.connect(g);g.connect(MASTER);droneNodes={g,o};}catch(e){}
 const pat=[1,0,.5,0,1,.6,.5,0];
 ambTimer=setInterval(()=>{if(!AC||G.mode!=='play')return;const v=pat[ambStep%8];ambStep++;if(v>0){const t=AC.currentTime;thud(t,v>.9?62:84,.13*v,.45);}},520);
}

/* ---------- three setup ---------- */
const canvas=$('#c');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
if(THREE.sRGBEncoding)renderer.outputEncoding=THREE.sRGBEncoding;
if(THREE.ACESFilmicToneMapping){renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;}
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x0a0c13);
scene.fog=new THREE.FogExp2(0x0a0c13,.016);
let VW=320,VH=560;
function resize(){
 const r=$('#app').getBoundingClientRect();
 let sc=Math.min((window.devicePixelRatio||1)*.9,1.5);
 if(r.width*r.height*sc*sc>1.8e6)sc=Math.sqrt(1.8e6/(r.width*r.height));
 VW=Math.max(64,Math.floor(r.width*sc));VH=Math.max(64,Math.floor(r.height*sc));
 renderer.setSize(VW,VH,false);
}
window.addEventListener('resize',resize);resize();
const cams=[new THREE.PerspectiveCamera(60,.6,.1,300),new THREE.PerspectiveCamera(60,1,.1,300)];
const menuCam=new THREE.PerspectiveCamera(50,.6,.1,300);

scene.add(new THREE.HemisphereLight(0x9fb0e0,0x241a28,.9));
const moon=new THREE.DirectionalLight(0xcfdcff,1.0);
moon.position.set(-14,30,-12);moon.castShadow=true;
moon.shadow.mapSize.set(2048,2048);
Object.assign(moon.shadow.camera,{left:-24,right:24,top:24,bottom:-24,near:1,far:80});
moon.shadow.bias=-.0004;moon.shadow.camera.updateProjectionMatrix();scene.add(moon);
const fire1=new THREE.PointLight(0xff7a2a,1.3,30),fire2=new THREE.PointLight(0xff7a2a,1.3,30);
fire1.position.set(-17,4,17);fire2.position.set(17,4,-17);scene.add(fire1,fire2);

function noiseTex(c1,c2,sz){
 const cv=document.createElement('canvas');cv.width=cv.height=sz;const x=cv.getContext('2d');
 x.fillStyle=c1;x.fillRect(0,0,sz,sz);
 for(let i=0;i<2600;i++){x.fillStyle=Math.random()<.5?c2:'rgba(0,0,0,.08)';x.globalAlpha=Math.random()*.25;x.fillRect(Math.random()*sz,Math.random()*sz,rnd(1,5),rnd(1,3));}
 x.globalAlpha=.25;x.strokeStyle='rgba(0,0,0,.5)';x.lineWidth=1;
 for(let i=0;i<6;i++){x.beginPath();let px=Math.random()*sz,py=Math.random()*sz;x.moveTo(px,py);for(let k=0;k<5;k++){px+=rnd(-30,30);py+=rnd(-30,30);x.lineTo(px,py);}x.stroke();}
 const t=new THREE.CanvasTexture(cv);return t;
}
const BOARD=[];   // BOARD[i][j] tile mesh
const HL=[];      // highlight planes
(function buildArena(){
 const tL=noiseTex('#b9b4a6','#ffffff',128),tD=noiseTex('#2b2d36','#7b7f90',128);
 const mL=new THREE.MeshStandardMaterial({map:tL,roughness:.8,metalness:.05});
 const mD=new THREE.MeshStandardMaterial({map:tD,roughness:.6,metalness:.15});
 const gl=new THREE.BoxGeometry(3.94,.9,3.94);
 for(let i=0;i<8;i++){BOARD[i]=[];HL[i]=[];for(let j=0;j<8;j++){
  const m=new THREE.Mesh(gl,(i+j)%2?mL:mD);m.position.set(cellX(i),-.45,cellZ(j));m.receiveShadow=true;scene.add(m);BOARD[i][j]=m;
  const h=new THREE.Mesh(new THREE.PlaneGeometry(3.7,3.7),new THREE.MeshBasicMaterial({color:0xff2a2a,transparent:true,opacity:0,depthWrite:false}));
  h.rotation.x=-PI/2;h.position.set(cellX(i),.03,cellZ(j));h.renderOrder=2;h.visible=false;scene.add(h);HL[i][j]=h;
 }}
 const base=new THREE.Mesh(new THREE.BoxGeometry(34.6,1.4,34.6),new THREE.MeshStandardMaterial({color:0x3a2b1d,roughness:.9,map:noiseTex('#4a3724','#8a6a44',128)}));
 base.position.y=-1.15;base.receiveShadow=true;scene.add(base);
 const fr=new THREE.MeshStandardMaterial({color:0x6a4e2c,roughness:.7,metalness:.2});
 [[0,-16.5,34.6,1.2],[0,16.5,34.6,1.2],[-16.5,0,1.2,32],[16.5,0,1.2,32]].forEach(a=>{const m=new THREE.Mesh(new THREE.BoxGeometry(a[2],.7,a[3]),fr);m.position.set(a[0],.1,a[1]);m.castShadow=true;m.receiveShadow=true;scene.add(m);});
 const pm=new THREE.MeshStandardMaterial({color:0x707480,roughness:1,flatShading:true});
 for(let i=0;i<18;i++){
  const a=i/18*TAU,r=26+Math.random()*4,h=4+Math.random()*9;
  const c=new THREE.Mesh(new THREE.CylinderGeometry(1,1.25,h,8),pm);
  c.position.set(Math.sin(a)*r,h/2-2,Math.cos(a)*r);c.rotation.y=Math.random();c.rotation.z=rnd(-.07,.07);c.castShadow=true;c.receiveShadow=true;scene.add(c);
  if(Math.random()<.6){const cap=new THREE.Mesh(new THREE.BoxGeometry(2.8,.8,2.8),pm);cap.position.set(c.position.x,h-1.6,c.position.z);cap.rotation.y=c.rotation.y;scene.add(cap);}
 }
 const sg=new THREE.BufferGeometry(),pos=[];
 for(let i=0;i<500;i++){const a=Math.random()*TAU,b=Math.random()*1.2+.1,R=170;pos.push(Math.cos(a)*Math.cos(b)*R,Math.sin(b)*R,Math.sin(a)*Math.cos(b)*R);}
 sg.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));
 scene.add(new THREE.Points(sg,new THREE.PointsMaterial({color:0xffffff,size:1.8,fog:false})));
 const mn=new THREE.Mesh(new THREE.SphereGeometry(14,20,14),new THREE.MeshBasicMaterial({color:0xe6ecff,fog:false}));
 mn.position.set(-80,85,-125);scene.add(mn);
 const bm=new THREE.MeshStandardMaterial({color:0x2a2218,flatShading:true});
 [[-17,17],[17,-17],[-17,-17],[17,17]].forEach(p=>{const b=new THREE.Mesh(new THREE.CylinderGeometry(.6,.8,3,8),bm);b.position.set(p[0],1.5,p[1]);b.castShadow=true;scene.add(b);
  const f=new THREE.Mesh(new THREE.ConeGeometry(.6,1.3,6),new THREE.MeshBasicMaterial({color:0xffa040}));f.position.set(p[0],3.5,p[1]);scene.add(f);});
})();
const dustGeo=new THREE.BufferGeometry();const dustP=[];
for(let i=0;i<200;i++)dustP.push(rnd(-20,20),rnd(.3,10),rnd(-20,20));
dustGeo.setAttribute('position',new THREE.Float32BufferAttribute(dustP,3));
const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xcfd8ff,size:.13,transparent:true,opacity:.55}));
scene.add(dust);

/* ---------- models ---------- */
function mat(c,o){return new THREE.MeshStandardMaterial(Object.assign({color:c,flatShading:false,roughness:.5,metalness:.12},o||{}));}
function lathe(pts,seg){return new THREE.LatheGeometry(pts.map(p=>new THREE.Vector2(p[0],p[1])),seg||20);}
function mk(geo,m,x,y,z){const o=new THREE.Mesh(geo,m);o.position.set(x||0,y||0,z||0);o.castShadow=true;return o;}
const PROFILE={
 pawn:[[0,0],[.62,0],[.64,.14],[.5,.24],[.34,.34],[.28,.7],[.3,.95],[.46,1.05],[.46,1.14],[.3,1.2],[0,1.2]],
 rook:[[0,0],[.7,0],[.72,.18],[.52,.3],[.46,.4],[.4,1.15],[.55,1.3],[.6,1.5],[.5,1.5],[0,1.5]],
 bishop:[[0,0],[.65,0],[.66,.16],[.45,.28],[.3,.5],[.26,1.0],[.42,1.1],[.42,1.2],[.3,1.3],[.4,1.6],[.2,2.0],[.05,2.15],[0,2.15]],
 queen:[[0,0],[.7,0],[.72,.16],[.5,.3],[.34,.5],[.26,1.2],[.42,1.35],[.5,1.7],[.62,1.95],[.5,1.95],[0,1.9]],
 king:[[0,0],[.75,0],[.78,.2],[.55,.34],[.4,.6],[.34,1.3],[.52,1.5],[.6,1.9],[.46,2.0],[0,2.0]],
 knight:[[0,0],[.7,0],[.72,.16],[.5,.3],[.4,.6],[0,.6]]
};
const EYES={pawn:[1.52,.3],rook:[1.0,.42],bishop:[1.4,.3],queen:[1.55,.36],king:[1.55,.4],knight:[1.8,.9]};
function colorsFor(color,boss){
 if(color==='white')return {c:0xe6dfcb,e:0x1a1608};
 return {c:boss?0x3a1216:0x2a2630,e:boss?0x300606:0x14090c};
}
function buildPiece(type,color,opt){
 opt=opt||{};const g=new THREE.Group(),body=new THREE.Group();g.add(body);
 const cl=colorsFor(color,opt.boss);const M=mat(cl.c,{emissive:cl.e});const mats=[M];
 const dark=mat(0x15131a);mats.push(dark);
 body.add(mk(lathe(PROFILE[type],22),M));
 const add=(m)=>{body.add(m);return m;};
 if(type==='pawn'){add(mk(new THREE.IcosahedronGeometry(.34,1),M,0,1.5,0));}
 if(type==='rook'){for(let i=0;i<6;i++){const a=i/6*TAU;const b=mk(new THREE.BoxGeometry(.28,.3,.28),M,Math.sin(a)*.46,1.65,Math.cos(a)*.46);b.rotation.y=a;add(b);}}
 if(type==='bishop'){add(mk(new THREE.SphereGeometry(.12,6,5),M,0,2.28,0));add(mk(new THREE.BoxGeometry(.1,.5,.3),dark,0,1.75,.12));}
 if(type==='queen'){for(let i=0;i<8;i++){const a=i/8*TAU;add(mk(new THREE.ConeGeometry(.12,.55,4),M,Math.sin(a)*.5,2.15,Math.cos(a)*.5));}add(mk(new THREE.SphereGeometry(.16,6,5),M,0,2.15,0));}
 if(type==='king'){for(let i=0;i<6;i++){const a=i/6*TAU;add(mk(new THREE.ConeGeometry(.12,.45,4),M,Math.sin(a)*.5,2.15,Math.cos(a)*.5));}
  add(mk(new THREE.BoxGeometry(.16,.75,.16),M,0,2.65,0));add(mk(new THREE.BoxGeometry(.52,.15,.16),M,0,2.75,0));}
 if(type==='knight'){
  add(mk(new THREE.BoxGeometry(.55,1.2,.8),M,0,1.1,-.05)).rotation.x=.25;
  add(mk(new THREE.BoxGeometry(.5,.6,1.0),M,0,1.85,.35)).rotation.x=-.2;
  add(mk(new THREE.BoxGeometry(.38,.34,.5),M,0,1.65,.95)).rotation.x=-.2;
  add(mk(new THREE.ConeGeometry(.1,.3,4),M,.17,2.25,.1));add(mk(new THREE.ConeGeometry(.1,.3,4),M,-.17,2.25,.1));
  add(mk(new THREE.BoxGeometry(.12,.9,.35),dark,0,1.75,-.3)).rotation.x=.45;
 }
 let weapon=null;
 if(type==='pawn'){
  weapon=new THREE.Group();weapon.position.set(.55,1.0,.3);
  const pm=mat(0x8a6a3a);mats.push(pm);
  const pole=mk(new THREE.CylinderGeometry(.05,.05,3.2,5),pm);pole.rotation.x=PI/2;weapon.add(pole);
  const tip=mk(new THREE.ConeGeometry(.12,.5,4),mat(0xc4ccd4,{emissive:0x222a30}),0,0,1.75);tip.rotation.x=PI/2;weapon.add(tip);
  body.add(weapon);
 }
 const eyeM=new THREE.MeshBasicMaterial({color:opt.boss?0xffd23a:0xff2a2a});
 const ey=EYES[type];[-.13,.13].forEach(x=>{const e=new THREE.Mesh(new THREE.SphereGeometry(.07,5,4),eyeM);e.position.set(x*(type==='knight'?1.1:1),ey[0],ey[1]);body.add(e);});
 mats.forEach(m=>{m.userData.e0=m.emissive.clone();});
 return {g,body,mats,weapon,type};
}
function buildPawn(color){
 const m=buildPiece('pawn',color,{});
 m.body.remove(m.weapon);m.weapon=null;
 const sw=mat(0xb9c3cc,{emissive:0x1a2026,metalness:.5});m.mats.push(sw);sw.userData.e0=sw.emissive.clone();
 const mkArm=(side)=>{
  const p=new THREE.Group();p.position.set(-side*.5,.85,.1);
  const arm=mk(new THREE.CylinderGeometry(.08,.08,.5,5),sw);arm.rotation.x=PI/2;arm.position.z=.2;p.add(arm);
  const bl=mk(new THREE.BoxGeometry(.08,.1,1.5),sw,0,0,.95);p.add(bl);
  const gd=mk(new THREE.BoxGeometry(.4,.08,.1),sw,0,0,.4);p.add(gd);
  m.body.add(p);return p;
 };
 m.armL=mkArm(-1);m.armR=mkArm(1);
 m.armL.rotation.y=.25;m.armR.rotation.y=-.25;
 const gm=mat(0xd8b45a,{emissive:0x5a4310,metalness:.6});m.mats.push(gm);gm.userData.e0=gm.emissive.clone();
 const sh=new THREE.Group();sh.position.set(0,.95,.95);
 const disc=mk(new THREE.CylinderGeometry(.75,.75,.1,8),gm);disc.rotation.x=PI/2;sh.add(disc);
 sh.add(mk(new THREE.CylinderGeometry(.2,.2,.2,6),mat(0x15131a),0,0,0)).rotation.x=PI/2;
 sh.scale.set(.001,.001,.001);m.body.add(sh);m.shield=sh;
 return m;
}
function flashModel(m,a){
 for(const x of m.mats){const e=x.userData.e0;x.emissive.setRGB(e.r+a,e.g+a*.25,e.b+a*.25);}
}


/* ---------- particles ---------- */
const PARTS=[];
(function(){const geo=new THREE.BoxGeometry(.16,.16,.16);
 for(let i=0;i<200;i++){const m=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:0xffffff,transparent:true}));m.visible=false;scene.add(m);PARTS.push({m,v:new THREE.Vector3(),life:0,max:1,g:0,sz:1});}})();
function burst(x,y,z,n,col,spd,up,g,sz){
 let k=0;for(const p of PARTS){if(k>=n)break;if(p.life>0)continue;k++;
  p.life=p.max=rnd(.35,.8);p.g=g;p.sz=sz||1;p.m.position.set(x,y,z);p.m.material.color.setHex(col);p.m.visible=true;
  p.v.set(rnd(-1,1)*spd,rnd(0,1)*up,rnd(-1,1)*spd);}
}
function updateParts(dt){for(const p of PARTS){if(p.life<=0)continue;p.life-=dt;if(p.life<=0){p.m.visible=false;continue;}
 p.v.y-=p.g*dt;p.m.position.x+=p.v.x*dt;p.m.position.y+=p.v.y*dt;p.m.position.z+=p.v.z*dt;
 const k=p.life/p.max;p.m.scale.setScalar(p.sz*k);p.m.material.opacity=k;}}

/* ---------- global game state ---------- */
const G={mode:'menu',kind:null,fighters:[],enemies:[],main:null,level:1,info:null,D:DIFFS[2],hitstop:0,
 round:1,wins:[0,0],roundOver:false,endT:0,shake:0,time:0,pcolor:save.color};
let displayPawn=null,displayEnemy=null,dispT=0,dispIdx=0;
const pcolor=()=>save.color, ocolor=()=>save.color==='white'?'black':'white';

/* ---------- grid helpers (chess board 8x8) ---------- */
const inb=(i,j)=>i>=0&&i<8&&j>=0&&j<8;
function allUnits(){return G.fighters.concat(G.enemies);}
function occ(i,j,self){for(const u of allUnits()){if(u!==self&&!u.dead&&u.cx===i&&u.cz===j)return true;}return false;}
function stepTo(u,i,j,dur,h){u.fx0=u.x;u.fz0=u.z;u.cx=i;u.cz=j;u.hopT=0;u.hopD=dur;u.hopH=h===undefined?.5:h;}
function hopUpdate(u,dt){
 const tx=cellX(u.cx),tz=cellZ(u.cz);
 if(u.hopT<u.hopD){u.hopT+=dt;const k=Math.min(1,u.hopT/u.hopD),e=k*k*(3-2*k);u.x=lerp(u.fx0,tx,e);u.z=lerp(u.fz0,tz,e);u.hy=Math.sin(k*PI)*u.hopH;}
 else{u.x=tx;u.z=tz;u.hy=0;}
}
function placeUnit(u,i,j){u.cx=i;u.cz=j;u.x=cellX(i);u.z=cellZ(j);u.fx0=u.x;u.fz0=u.z;u.hopT=1;u.hopD=.2;u.hopH=0;u.hy=0;}
function faceCard(u,t){
 const dx=t.cx-u.cx,dz=t.cz-u.cz;if(!dx&&!dz)return;
 if(Math.abs(dx)>Math.abs(dz)){u.fx=Math.sign(dx);u.fz=0;}else{u.fx=0;u.fz=Math.sign(dz);}
}
// strike cells of a pawn facing (fx,fz) standing on (i,j): side +1 = front-left, -1 = front-right
function sCell(u,side){
 return side>0?[u.cx+u.fx+u.fz,u.cz+u.fz-u.fx]:[u.cx+u.fx-u.fz,u.cz+u.fz+u.fx];
}
const cheb=(a,b)=>Math.max(Math.abs(a.cx-b.cx),Math.abs(a.cz-b.cz));
function lineCells(i,j,sx,sz){const o=[];for(let k=1;k<9;k++){const x=i+sx*k,z=j+sz*k;if(!inb(x,z))break;o.push([x,z]);}return o;}
const bothWays=(i,j,sx,sz)=>lineCells(i,j,sx,sz).concat(lineCells(i,j,-sx,-sz));
function shove(u){
 const d=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,1],[1,-1],[-1,-1]];
 for(const v of d){const i=u.cx+v[0],j=u.cz+v[1];if(inb(i,j)&&!occ(i,j,u)){stepTo(u,i,j,.18,.8);return;}}
}

/* ---------- Fighter (pawn: player / bot / player 2) ---------- */
class Fighter{
 constructor(color,name,idx,view){
  this.color=color;this.name=name;this.idx=idx;this.view=view;this.m=buildPawn(color);this.g=this.m.g;this.g.scale.setScalar(1.35);scene.add(this.g);
  this.dmg=12;this.inp={f:0,b:0,l:0,r:0,s:0,pL:0,pR:0,pf:0,pb:0,pl:0,pr:0};this.bot=null;this.spdMul=1;this.yaw=0;
 }
 reset(i,j){
  Object.assign(this,{hp:100,maxhp:100,st:100,stCd:0,atkT:9,side:0,atkHit:true,shield:false,stun:0,inv:0,flash:0,dead:false,t:0,fall:0,moveCd:0,recoil:0,hy:0});
  this.hd={};this.fx=0;this.fz=this.view;this.yaw=Math.atan2(this.fx,this.fz);placeUnit(this,i,j);
  this.g.visible=true;this.g.rotation.set(0,this.yaw,0);this.g.position.set(this.x,0,this.z);flashModel(this.m,0);
 }
 dirs(k){const x=this.fx,z=this.fz;return k==='f'?[x,z]:k==='b'?[-x,-z]:k==='l'?[z,-x]:[-z,x];}
 tryStep(dx,dz){
  if(this.moveCd>0||this.hopT<this.hopD||this.atkT<.3||this.stun>0||this.dead)return false;
  const i=this.cx+dx,j=this.cz+dz;if(!inb(i,j)||occ(i,j,this))return false;
  stepTo(this,i,j,.2,.55);if(!this.bot){this.fx=dx;this.fz=dz;}this.moveCd=(this.shield?.5:.3)/this.spdMul;sfx('step');return true;
 }
 startAtk(side){this.atkT=0;this.side=side;this.atkHit=false;sfx('swing');}
 hurt(dmg,sx,sz,blockable){
  if(this.dead||this.inv>0)return 'none';
  if(blockable!==false&&this.shield&&this.st>0){
   this.st-=Math.max(14,dmg*1.15);this.stCd=.9;sfx('block');this.recoil=.5;
   burst(this.x+this.fx*1.6,1.6,this.z+this.fz*1.6,14,0xbfe0ff,5,4,8,1.2);this.inv=.12;
   if(this.st<=0){this.st=0;this.stun=1.0;this.shield=false;burst(this.x,1.8,this.z,18,0xffe38a,6,6,8,1.4);}
   return 'block';
  }
  this.hp-=dmg;this.flash=.28;this.inv=.32;this.atkT=Math.max(this.atkT,.45);sfx('hurt');this.recoil=1;
  burst(this.x,1.5,this.z,18,0xc01914,5,5,10,1.2);
  G.shake=Math.max(G.shake,.6);G.hitstop=.06;
  if(this.idx===0&&G.kind==='campaign'){const f=$('#flash');f.style.opacity=.55;setTimeout(()=>f.style.opacity=0,90);}
  if(this.hp<=0){this.hp=0;this.dead=true;sfx('die');burst(this.x,1,this.z,34,0xc01914,6,7,10,1.6);}
  return 'hit';
 }
 update(dt,foes){
  this.t+=dt;hopUpdate(this,dt);
  if(this.recoil>0)this.recoil=Math.max(0,this.recoil-dt*4);
  if(this.dead){this.fall=Math.min(1,this.fall+dt*2);return;}
  const inp=this.inp,now=nowS();
  if(this.inv>0)this.inv-=dt;if(this.flash>0)this.flash-=dt;
  this.atkT+=dt;this.moveCd-=dt;
  // lock on nearest foe (face along a rank/file, like a chess piece)
  let tg=null,bd=99;for(const f of foes){if(f.dead)continue;const d=cheb(this,f);if(d<bd){bd=d;tg=f;}}
  if(tg&&this.bot&&this.atkT>.5)faceCard(this,tg);
  if(this.stun>0){this.stun-=dt;this.shield=false;}
  else{
   this.shield=!!inp.s&&this.atkT>.4&&this.st>0;
   if(!this.bot){
    for(const k of ['f','b','l','r']){
     const held=inp[k],buf=inp['p'+k]&&now-inp['p'+k]<.18;
     if(!held)this.hd[k]=null;
     if(held||buf){const v=(held&&this.hd[k])?this.hd[k]:this.dirs(k);
      if(this.tryStep(v[0],v[1])){if(held)this.hd[k]=v;inp['p'+k]=0;break;}}
    }
   }
   if(this.atkT>=.5&&!this.shield&&this.hopT>=this.hopD){
    if(inp.pL&&now-inp.pL<.28){inp.pL=0;this.startAtk(1);}
    else if(inp.pR&&now-inp.pR<.28){inp.pR=0;this.startAtk(-1);}
   }
  }
  if(!this.shield){this.stCd-=dt;if(this.stCd<=0)this.st=Math.min(100,this.st+24*dt);}
  if(this.atkT>=.16&&!this.atkHit){
   this.atkHit=true;const c=sCell(this,this.side);let hit=false;
   if(inb(c[0],c[1])){
    for(const f of foes){if(f.dead)continue;if(f.cx===c[0]&&f.cz===c[1]){hit=true;f.hurt(this.dmg,this.x,this.z,true,this);}}
    G.mark={i:c[0],j:c[1],t:.25};
   }
   if(!hit){burst(cellX(c[0]),.6,cellZ(c[1]),6,0xffffff,2,2,6,.8);}
  }
 }
 animate(dt){
  const m=this.m,g=this.g,t=this.t;
  const ty=Math.atan2(this.fx,this.fz);this.yaw+=angDiff(this.yaw,ty)*Math.min(1,dt*14);
  const rc=this.recoil*.5;
  g.position.set(this.x-this.fx*rc,this.hy,this.z-this.fz*rc);
  g.rotation.y=this.yaw;
  if(this.dead){g.rotation.z=this.fall*1.45;g.position.y=-this.fall*.3;}
  else{g.rotation.z=0;g.rotation.x=this.atkT>.1&&this.atkT<.3?.18:0;}
  m.body.scale.y=1+Math.sin(t*3)*.015;
  const a=this.atkT;let aL=.25,aR=-.25;
  if(a<.55){
   const sw=a<.14?-1.4-(a/.14)*.2:(a<.32?lerp(-1.6,.5,(a-.14)/.18):lerp(.5,-.25,Math.min(1,(a-.32)/.2)));
   if(this.side<0)aR=sw;else if(this.side>0)aL=-sw;
  }
  m.armL.rotation.y=lerp(m.armL.rotation.y,aL,Math.min(1,dt*(a<.55?40:10)));
  m.armR.rotation.y=lerp(m.armR.rotation.y,aR,Math.min(1,dt*(a<.55?40:10)));
  m.armL.rotation.x=m.armR.rotation.x=this.shield?-.6:0;
  const ts=this.shield?1:.001;const s=lerp(m.shield.scale.x,ts,Math.min(1,dt*14));m.shield.scale.set(s,s,s);
  flashModel(m,this.flash>0?this.flash*2.4:(this.stun>0?.35:0));
 }
}

/* ---------- Enemy (chess piece) ---------- */
const SCALE={pawn:1.7,knight:2.0,bishop:2.0,rook:2.0,queen:2.3,king:2.5};
class Enemy{
 constructor(type,color,S,opt){
  opt=opt||{};this.type=type;this.boss=!!opt.boss;this.minion=!!opt.minion;
  this.S=Object.assign({},S);this.m=buildPiece(type,color,{boss:this.boss});this.g=this.m.g;
  this.sc=(this.boss?3.0:SCALE[type])*(opt.mul||1);this.g.scale.setScalar(this.sc);scene.add(this.g);
  this.name=(this.boss?'وزیر خونین':PN[type]);this.hp=this.maxhp=this.S.hp;this.dmg=this.S.dmg;
  this.cool=1.6;this.atk=null;this.stun=0;this.stunVuln=false;this.flash=0;this.dead=false;this.t=Math.random()*5;
  this.mvCd=0;this.sub=null;this.summoned=0;this.dieT=0;this.plan=null;this.fx=0;this.fz=-1;this.yaw=PI;this.recoil=0;this.stunNext=0;
  if(this.boss){this.light=new THREE.PointLight(0xff2a1a,1.8,18);this.g.add(this.light);this.light.position.y=2;}
  placeUnit(this,3,6);
 }
 hurt(dmg){
  if(this.dead)return 'none';
  this.hp-=dmg*(this.stunVuln?1.6:1);this.flash=.2;sfx('hit');this.recoil=.6;
  burst(this.x,1.8,this.z,16,this.stunVuln?0xffe38a:0xffb347,5,5,9,1.2);
  G.hitstop=.05;G.shake=Math.max(G.shake,.25);
  if(this.hp<=0){this.hp=0;this.die();}
  return 'hit';
 }
 die(){this.dead=true;this.dieT=0;clearAtk(this);sfx('die');sfx('boom');burst(this.x,1.8,this.z,50,0x9dffd0,5,9,-3,1.6);G.shake=.9;}
 update(dt){
  this.t+=dt;hopUpdate(this,dt);
  if(this.recoil>0)this.recoil=Math.max(0,this.recoil-dt*4);
  if(this.dead){this.dieT+=dt;this.g.position.y=this.dieT*1.6;const s=this.sc*Math.max(0,1-this.dieT/1.3);this.g.scale.setScalar(Math.max(.001,s));this.g.rotation.y+=dt*6;if(this.dieT>1.4)this.g.visible=false;return;}
  if(this.flash>0)this.flash-=dt;
  const tg=G.fighters[0];this.cool-=dt;this.mvCd-=dt;
  if(this.stun>0){this.stun-=dt;if(this.stun<=0){this.stunVuln=false;this.cool=.5*this.S.cd;}}
  else if(this.atk)updateAtk(this,dt);
  else if(tg&&!tg.dead){faceCard(this,tg);think(this,tg,dt);}
  if(this.boss&&!this.summoned&&this.hp<this.maxhp*.5){this.summoned=1;summon(this,2);}
  if(this.boss&&this.summoned===1&&this.hp<this.maxhp*.22){this.summoned=2;summon(this,2);}
  if(this.type==='king'&&!this.summoned&&this.hp<this.maxhp*.6){this.summoned=1;summon(this,2);}
 }
 animate(dt){
  if(this.dead)return;
  const g=this.g,b=this.m.body,t=this.t,a=this.atk;
  const ty=Math.atan2(this.fx,this.fz);this.yaw+=angDiff(this.yaw,ty)*Math.min(1,dt*10);
  let lean=0,hov=0,sq=1;
  if(a){
   const k=a.phase==='tele'?clamp(a.t/a.tele,0,1):1;
   if(a.phase==='tele'){lean=-.35*k;sq=1+.07*k;if(this.type==='bishop')hov=.9*k;}
   else if(a.phase==='act'){lean=.5;if(this.type==='bishop')hov=.9;}
   if(this.m.weapon)this.m.weapon.position.z=a.phase==='tele'?lerp(.3,-.5,k):(a.phase==='act'?1.1:.3);
  }else if(this.m.weapon)this.m.weapon.position.z=lerp(this.m.weapon.position.z,.3,Math.min(1,dt*8));
  b.rotation.x=lerp(b.rotation.x,lean,Math.min(1,dt*18));
  b.scale.set(1,sq+Math.sin(t*2.2)*.02,1);
  const rc=this.recoil*.4;
  g.position.set(this.x-this.fx*rc,this.hy+hov,this.z-this.fz*rc);g.rotation.y=this.yaw;
  flashModel(this.m,this.flash>0?this.flash*3:(this.stunVuln?.28+Math.sin(t*20)*.1:0)+(a&&a.phase==='tele'?.12+Math.sin(t*30)*.08:0));
 }
}
function clearAtk(e){e.atk=null;e.plan=null;}
function summon(e,n){
 const S=enemyStats(G.info,G.D,'pawn');S.hp*=.3;let made=0;
 for(let r=1;r<4&&made<n;r++)for(let i=0;i<8&&made<n;i++)for(let j=0;j<8&&made<n;j++){
  if(Math.max(Math.abs(i-e.cx),Math.abs(j-e.cz))!==r||occ(i,j,null))continue;
  const m=new Enemy('pawn',ocolor(),S,{minion:true,mul:.8});placeUnit(m,i,j);m.cool=1.4;G.enemies.push(m);made++;
  burst(m.x,.5,m.z,16,0xff4040,4,6,6,1.4);}
 sfx('boss');G.shake=.6;
}
function beginAtk(e,o){
 const a=Object.assign({phase:'tele',t:0,dmgMul:1,act:.22,rec:.6,cells:[]},o);
 a.tele=Math.max(.32,(o.tele||.7)*e.S.tele*(e.enrage?.85:1));a.rec=(o.rec||.6)*Math.min(1.4,e.S.cd);
 e.atk=a;e.sub=null;sfx('tele');
}
function strikeCells(e,a,cells){
 const p=G.fighters[0];if(!p||p.dead)return;
 for(const c of (cells||a.cells)){if(c[0]===p.cx&&c[1]===p.cz){p.hurt(e.dmg*a.dmgMul,e.x,e.z,!a.unblock);return;}}
}
function updateAtk(e,dt){
 const a=e.atk;a.t+=dt;
 if(a.phase==='tele'){if(a.t>=a.tele){a.phase='act';a.t=0;fireAtk(e,a);}}
 else if(a.phase==='act'){
  if(a.delay&&!a.landed&&a.t>=a.delay){a.landed=true;
   strikeCells(e,a);if(a.shoveP){const p=G.fighters[0];if(p&&!p.dead&&p.cx===e.cx&&p.cz===e.cz)shove(p);}
   G.shake=.8;sfx('land');burst(e.x,.3,e.z,28,0xb0a890,7,5,9,1.5);}
  if(a.t>=Math.max(a.act,(a.delay||0)+.12)){a.phase='rec';a.t=0;}
 }else if(a.t>=a.rec){e.atk=null;e.cool=e.S.cd*rnd(.5,1.1);if(e.stunNext>0){e.stun=e.stunNext;e.stunVuln=true;e.stunNext=0;G.shake=.7;sfx('boom');}}
}
function fireAtk(e,a){
 if(!a.delay)strikeCells(e,a);
 if(a.onFire)a.onFire(e,a);
 if(a.beam){sfx('beam');G.shake=Math.max(G.shake,.3);}else if(a.slam){sfx('boom');G.shake=.8;burst(e.x,.3,e.z,30,0xb0a890,8,5,9,1.5);}else if(!a.delay)sfx('swing');
}

/* ---------- enemy brains (chess movement) ---------- */
function bestCell(e,pred){
 let best=null,bd=1e9;
 for(let i=0;i<8;i++)for(let j=0;j<8;j++){if(occ(i,j,e)||!pred(i,j))continue;const d=Math.abs(i-e.cx)+Math.abs(j-e.cz);if(d<bd){bd=d;best=[i,j];}}
 return best;
}
function alignThen(e,cell,dur,h,mk){
 if(cell&&(cell[0]!==e.cx||cell[1]!==e.cz))stepTo(e,cell[0],cell[1],dur,h);
 e.plan=mk;
}
function pawnCells(e){
 const fl=sCell(e,1),fr=sCell(e,-1);
 return [[e.cx+e.fx,e.cz+e.fz],fl,fr].filter(c=>inb(c[0],c[1]));
}
function think(e,p,dt){
 if(e.plan){if(e.hopT>=e.hopD){const f=e.plan;e.plan=null;f();}return;}
 if(e.boss&&e.hp<e.maxhp*.35&&!e.enrage){e.enrage=true;e.S.spd*=1.2;sfx('boss');G.shake=.8;banner('وزیر خشمگین شد!',900);}
 const type=e.type==='queen'?(e.sub||(e.sub=pickQueen(e))):e.type;
 const sp=e.S.spd*(e.type==='queen'?1.15:1);
 const ch=cheb(e,p);
 switch(type){
  case 'pawn':{
   if(e.cool<=0&&ch<=1){beginAtk(e,{tele:.62,rec:.6,cells:pawnCells(e)});}
   else if(ch>1&&e.mvCd<=0&&e.hopT>=e.hopD){
    let best=null,bd=1e9;for(const v of [[1,0],[-1,0],[0,1],[0,-1]]){const i=e.cx+v[0],j=e.cz+v[1];if(!inb(i,j)||occ(i,j,e))continue;
     const d=Math.abs(i-p.cx)+Math.abs(j-p.cz);if(d<bd){bd=d;best=[i,j];}}
    if(best){stepTo(e,best[0],best[1],.25,.6);e.mvCd=.6/sp;sfx('step');}
   }break;}
  case 'knight':{
   if(e.cool<=0){
    let best=null,bd=1e9;
    for(const o of [[2,1],[2,-1],[-2,1],[-2,-1],[1,2],[1,-2],[-1,2],[-1,-2]]){
     const i=e.cx+o[0],j=e.cz+o[1];if(!inb(i,j))continue;
     if(occ(i,j,e)&&!(p.cx===i&&p.cz===j))continue;
     const d=Math.abs(i-p.cx)+Math.abs(j-p.cz);if(d<bd){bd=d;best=[i,j];}}
    if(best){
     const [i,j]=best;const cells=[[i,j],[i+1,j],[i-1,j],[i,j+1],[i,j-1]].filter(c=>inb(c[0],c[1]));
     beginAtk(e,{tele:.95,act:.4,rec:.9,cells,delay:.55,shoveP:true,
      onFire:(en)=>{stepTo(en,i,j,.55,5.5);}});
     e.atk.land=[i,j];
    }
   }break;}
  case 'bishop':{
   if(e.cool<=0){
    const cell=bestCell(e,(i,j)=>{const dx=Math.abs(i-p.cx),dz=Math.abs(j-p.cz);return dx===dz&&dx>=2;})||[e.cx,e.cz];
    alignThen(e,cell,.3,.9,()=>{
     const sx=Math.sign(p.cx-e.cx)||1,sz=Math.sign(p.cz-e.cz)||1;
     beginAtk(e,{tele:.95,act:.3,rec:.7,beam:true,cells:bothWays(e.cx,e.cz,sx,sz)});});
   }break;}
  case 'rook':{
   if(e.cool<=0){
    const cell=bestCell(e,(i,j)=>(i===p.cx||j===p.cz)&&Math.max(Math.abs(i-p.cx),Math.abs(j-p.cz))>=2)||[e.cx,e.cz];
    alignThen(e,cell,.3,0,()=>{
     const horiz=e.cz===p.cz||(e.cx!==p.cx&&Math.abs(e.cz-p.cz)<=Math.abs(e.cx-p.cx));
     const dir=horiz?[Math.sign(p.cx-e.cx)||1,0]:[0,Math.sign(p.cz-e.cz)||1];
     const cells=bothWays(e.cx,e.cz,horiz?1:0,horiz?0:1);
     beginAtk(e,{tele:1.0,act:.3,rec:.5,cells,dmgMul:1.2,beam:true,
      onFire:(en)=>{let i=en.cx,j=en.cz;while(true){const ni=i+dir[0],nj=j+dir[1];if(!inb(ni,nj)||occ(ni,nj,en))break;i=ni;j=nj;}
       if(i!==en.cx||j!==en.cz)stepTo(en,i,j,.28,0);en.stunNext=1.3;}});});
   }break;}
  case 'star':{
   if(e.cool<=0){
    const cell=bestCell(e,(i,j)=>{const dx=Math.abs(i-p.cx),dz=Math.abs(j-p.cz);return (dx===dz||dx===0||dz===0)&&Math.max(dx,dz)>=2;})||[e.cx,e.cz];
    alignThen(e,cell,.3,.6,()=>{
     const cells=bothWays(e.cx,e.cz,1,0).concat(bothWays(e.cx,e.cz,0,1),bothWays(e.cx,e.cz,1,1),bothWays(e.cx,e.cz,1,-1));
     beginAtk(e,{tele:1.25,act:.3,rec:.8,cells,beam:true});});
   }break;}
  case 'checker':{
   if(e.cool<=0){const par=(p.cx+p.cz)%2;const cells=[];for(let i=0;i<8;i++)for(let j=0;j<8;j++)if((i+j)%2===par&&!(i===e.cx&&j===e.cz))cells.push([i,j]);
    beginAtk(e,{tele:1.5,act:.35,rec:.9,cells,unblock:true,slam:true,dmgMul:.9});}
   break;}
  case 'ring':{
   if(ch>2&&e.mvCd<=0&&e.hopT>=e.hopD){let best=null,bd=1e9;for(const v of [[1,0],[-1,0],[0,1],[0,-1]]){const i=e.cx+v[0],j=e.cz+v[1];if(!inb(i,j)||occ(i,j,e))continue;
     const d=Math.abs(i-p.cx)+Math.abs(j-p.cz);if(d<bd){bd=d;best=[i,j];}}
    if(best){stepTo(e,best[0],best[1],.25,.6);e.mvCd=.5/sp;sfx('step');}}
   if(e.cool<=0&&ch<=3){const cells=[];for(let i=0;i<8;i++)for(let j=0;j<8;j++){const d=Math.max(Math.abs(i-e.cx),Math.abs(j-e.cz));if(d>=1&&d<=2)cells.push([i,j]);}
    beginAtk(e,{tele:1.1,act:.3,rec:.9,cells,slam:true});}
   break;}
  case 'king':{
   if(ch>1&&e.mvCd<=0&&e.hopT>=e.hopD){let best=null,bd=1e9;for(const v of [[1,0],[-1,0],[0,1],[0,-1]]){const i=e.cx+v[0],j=e.cz+v[1];if(!inb(i,j)||occ(i,j,e))continue;
     const d=Math.abs(i-p.cx)+Math.abs(j-p.cz);if(d<bd){bd=d;best=[i,j];}}
    if(best){stepTo(e,best[0],best[1],.3,.6);e.mvCd=.9/sp;sfx('step');}}
   if(e.cool<=0&&ch<=2){
    if(Math.random()<.5){const cells=[];for(let i=0;i<8;i++)for(let j=0;j<8;j++){const d=Math.max(Math.abs(i-e.cx),Math.abs(j-e.cz));if(d===1)cells.push([i,j]);}beginAtk(e,{tele:1.1,act:.3,rec:.9,cells,slam:true});}
    else{const cells=[];for(let f=1;f<=3;f++)for(let s=-1;s<=1;s++){const i=e.cx+e.fx*f+(-e.fz)*s,j=e.cz+e.fz*f+e.fx*s;if(inb(i,j))cells.push([i,j]);}beginAtk(e,{tele:.9,rec:.8,cells});}
   }break;}
 }
}
function pickQueen(e){
 const list=['rook','bishop','star','knight'];if(e.boss)list.push('checker','ring','checker','star');
 return list[Math.floor(Math.random()*list.length)];
}

/* ---------- Bot brain (pawn fighter) ---------- */
function botThink(b,foe,dt){
 const P=[{react:1.0,blk:.1,spd:.7},{react:.8,blk:.3,spd:.85},{react:.55,blk:.5,spd:1},
          {react:.38,blk:.7,spd:1.1},{react:.25,blk:.88,spd:1.25},{react:.12,blk:.97,spd:1.5}][b.bot];
 b.spdMul=P.spd;b.bt=(b.bt||0)-dt;b.mt=(b.mt||0)-dt;
 const inCells=(u,v)=>[sCell(u,1),sCell(u,-1)].some(c=>c[0]===v.cx&&c[1]===v.cz);
 const threat=foe.atkT<.3&&!foe.atkHit&&inCells(foe,b);
 if(threat&&!b.sh&&Math.random()<P.blk*7*dt)b.sh=.55;
 if(b.sh>0){b.sh-=dt;b.inp.s=1;}else{b.sh=0;b.inp.s=0;}
 if(b.inp.s||b.stun>0||b.dead)return;
 const L=inCells(b,foe)?(()=>{const l=sCell(b,1);return l[0]===foe.cx&&l[1]===foe.cz?1:-1;})():0;
 if(L&&b.bt<=0&&b.atkT>.55&&b.hopT>=b.hopD){b.bt=P.react*rnd(.6,1.3);b.startAtk(L);return;}
 if(!L&&b.mt<=0&&b.moveCd<=0&&b.hopT>=b.hopD&&b.atkT>.4){
  b.mt=P.react*.5;
  const cost=(nx,nz)=>{const dx=foe.cx-nx,dz=foe.cz-nz;let fx,fz;if(Math.abs(dx)>Math.abs(dz)){fx=Math.sign(dx);fz=0;}else{fx=0;fz=Math.sign(dz)||b.view;}
   const front=dx*fx+dz*fz,side=dx*(-fz)+dz*fx;let c=Math.abs(front-1)+Math.abs(Math.abs(side)-1);
   const nf={cx:foe.cx,cz:foe.cz,fx:foe.fx,fz:foe.fz};if(foe.atkT>.5&&inCells(nf,{cx:nx,cz:nz}))c+=.8;return c;};
  let best=null,bc=cost(b.cx,b.cz)-.01;
  for(const v of [[1,0],[-1,0],[0,1],[0,-1]]){const i=b.cx+v[0],j=b.cz+v[1];if(!inb(i,j)||occ(i,j,b))continue;const c=cost(i,j)+Math.random()*.2;if(c<bc){bc=c;best=v;}}
  if(best)b.tryStep(best[0],best[1]);
 }
}

/* ---------- strike-cell highlights ---------- */
function updateHL(dt){
 const op=[],col=[];for(let i=0;i<8;i++){op[i]=[];col[i]=[];for(let j=0;j<8;j++){op[i][j]=0;col[i][j]=0xff2a2a;}}
 for(const e of G.enemies){const a=e.atk;if(!a||e.dead)continue;
  for(const c of a.cells){if(!inb(c[0],c[1]))continue;
   if(a.phase==='tele'){const k=a.t/a.tele;op[c[0]][c[1]]=.25+.3*k+.12*Math.sin(a.t*24);col[c[0]][c[1]]=0xff2a2a;}
   else if(a.phase==='act'&&a.t<.3){op[c[0]][c[1]]=.85;col[c[0]][c[1]]=0xffffff;}}}
 if(G.mode==='play'||G.mode==='over'){
  for(const f of G.fighters){if(f.bot||f.dead)continue;
   for(const s of [1,-1]){const c=sCell(f,s);if(inb(c[0],c[1])&&op[c[0]][c[1]]<.2){op[c[0]][c[1]]=.2+(f.atkT<.5&&f.side===s?.3:0);col[c[0]][c[1]]=f.atkT<.5&&f.side===s?0xffffff:0x7fe6ff;}}}
 }
 for(let i=0;i<8;i++)for(let j=0;j<8;j++){const h=HL[i][j],o=op[i][j];h.visible=o>0;if(o>0){h.material.opacity=o;h.material.color.setHex(col[i][j]);}}
}

/* ---------- Banner / HUD ---------- */
let bannerTO=0;
function banner(html,ms){const b=$('#banner');b.innerHTML=html;b.classList.add('on');clearTimeout(bannerTO);bannerTO=setTimeout(()=>b.classList.remove('on'),ms||1500);}
function setBar(el,k){el.style.width=clamp(k,0,1)*100+'%';}
const eBar=$('#eBar'),pBar=$('#pBar');
function hudUpdate(){
 const p=G.fighters[0],o=G.kind==='campaign'?G.main:G.fighters[1];
 if(p){setBar(pBar.querySelector('.bar:not(.st) i'),p.hp/p.maxhp);setBar(pBar.querySelector('.st i'),p.st/100);}
 if(o)setBar(eBar.querySelector('i'),o.hp/o.maxhp);
}

/* ---------- Controls ---------- */
function bindBtn(el,on,off){
 const dn=e=>{e.preventDefault();el.classList.add('on');on();};
 const up=e=>{e.preventDefault();el.classList.remove('on');off&&off();};
 el.addEventListener('pointerdown',dn);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);el.addEventListener('pointerleave',up);
}
function buildCtl(el,idx){
 el.innerHTML=`<div class="dp"><div class="cb up" data-k="f">▲</div><div class="cb lf" data-k="l">◀</div><div class="cb rt" data-k="r">▶</div><div class="cb dn" data-k="b">▼</div></div>
 <div class="ac"><div class="cb bl" data-k="L">⚔<small>ضربه چپ ↖</small></div><div class="cb br" data-k="R">⚔<small>ضربه راست ↗</small></div><div class="cb sh" data-k="S">🛡<small>سپر</small></div></div>`;
 el.querySelectorAll('.cb').forEach(b=>{
  const k=b.dataset.k;
  bindBtn(b,()=>{audioInit();const f=G.fighters[idx];if(!f)return;
   if(k==='L')f.inp.pL=nowS();else if(k==='R')f.inp.pR=nowS();
   else if(k==='S')f.inp.s=1;else{f.inp[k]=1;f.inp['p'+k]=nowS();}},
   ()=>{const f=G.fighters[idx];if(!f)return;if(k==='S')f.inp.s=0;else if(k!=='L'&&k!=='R')f.inp[k]=0;});
 });
}
buildCtl($('#ctl1'),0);buildCtl($('#ctl2'),1);
const KEYS={KeyW:[0,'f'],KeyS:[0,'b'],KeyA:[0,'l'],KeyD:[0,'r'],Space:[0,'s'],ShiftLeft:[0,'s'],
 ArrowUp:[1,'f'],ArrowDown:[1,'b'],ArrowLeft:[1,'l'],ArrowRight:[1,'r'],Digit3:[1,'s']};
function keyTarget(k){return (G.kind!=='pvp'&&k[0]===1)?0:k[0];}
window.addEventListener('keydown',e=>{
 audioInit();
 if(e.code==='Escape'){if(G.mode==='play')pauseGame();else if(G.mode==='pause')resumeGame();return;}
 const k=KEYS[e.code];
 if(k){const f=G.fighters[keyTarget(k)];if(f&&!e.repeat){if(k[1]==='s')f.inp.s=1;else{f.inp[k[1]]=1;f.inp['p'+k[1]]=nowS();}}e.preventDefault();return;}
 const f0=G.fighters[0],f1=G.fighters[1];
 if(e.code==='KeyQ'&&f0)f0.inp.pL=nowS();
 if(e.code==='KeyE'&&f0)f0.inp.pR=nowS();
 if(G.kind==='pvp'&&f1){if(e.code==='Digit1')f1.inp.pL=nowS();if(e.code==='Digit2')f1.inp.pR=nowS();}
});
window.addEventListener('keyup',e=>{
 const k=KEYS[e.code];if(!k)return;
 const f=G.fighters[keyTarget(k)];if(f)f.inp[k[1]]=0;
});
document.addEventListener('contextmenu',e=>e.preventDefault());

/* ---------- Game flow ---------- */
function clearWorld(){
 G.fighters.forEach(f=>scene.remove(f.g));G.enemies.forEach(e=>scene.remove(e.g));
 G.fighters=[];G.enemies=[];G.main=null;camState[0]={};camState[1]={};
 PARTS.forEach(p=>{p.life=0;p.m.visible=false;});
}
function setupHud(kind){
 $('#hud').classList.remove('hidden');$('#ctl1').classList.remove('hidden');
 const two=kind==='pvp';
 $('#ctl2').classList.toggle('hidden',!two);$('#ctl1').classList.toggle('two',two);
 [eBar,pBar].forEach(b=>b.classList.toggle('two',two));
}
function hideGame(){$('#hud').classList.add('hidden');$('#ctl1').classList.add('hidden');$('#ctl2').classList.add('hidden');}
function startCampaign(L){
 audioInit();clearWorld();hideMenuScene();
 G.kind='campaign';G.level=L;G.D=DIFFS[save.diff];G.info=levelInfo(L);G.pcolor=pcolor();
 const info=G.info;
 const p=new Fighter(pcolor(),'تو',0,1);p.reset(3,1);
 const S=enemyStats(info,G.D);
 const e=new Enemy(info.type,ocolor(),S,{boss:info.boss});placeUnit(e,4,6);e.fx=0;e.fz=-1;e.yaw=PI;
 G.fighters=[p];G.enemies=[e];G.main=e;G.endT=0;G.roundOver=false;
 setupHud('campaign');
 eBar.querySelector('.nm').textContent=`${GL[e.type]} ${e.name} — مرحله ${fa(L)}`;
 eBar.querySelector('.bar').classList.toggle('boss',info.boss);
 pBar.querySelector('.nm').textContent=G.D.em+' '+G.D.name;
 G.mode='play';ui(null);ambience(true);
 if(info.boss){sfx('boss');banner(`⚠ باس فایت: وزیر<small>${info.final?'مرحله نهایی — وزیر مطلق':'مرحله '+fa(L)}</small>`,2600);e.cool=2.8;}
 else if(L<=3)banner(`مرحله ${fa(L)} — ${PN[info.type]}<small>مثل شطرنج! روی خونه‌ها حرکت کن؛ هر طرف بری دوربین پشت سرت می‌چرخه. ضربه‌ات فقط قطریه (↖ ↗). از خونه‌های قرمز فرار کن</small>`,3800);
 else banner(`مرحله ${fa(L)}<small>${PN[info.type]}</small>`,1400);
}
function startBot(){audioInit();clearWorld();hideMenuScene();G.kind='bot';G.D=DIFFS[save.diff];newMatch(true);}
function startPvp(){audioInit();clearWorld();hideMenuScene();G.kind='pvp';newMatch(false);}
function newMatch(bot){
 const p=new Fighter(pcolor(),'بازیکن ۱',0,1);
 const o=new Fighter(ocolor(),bot?'ربات':'بازیکن ۲',1,-1);
 if(bot)o.bot=G.D.bot;
 G.fighters=[p,o];G.enemies=[];G.main=null;G.wins=[0,0];G.round=1;
 setupHud(bot?'bot':'pvp');
 eBar.querySelector('.nm').textContent=bot?`🤖 ربات (${G.D.em} ${G.D.name})`:'بازیکن ۲';
 eBar.querySelector('.bar').classList.remove('boss');
 pBar.querySelector('.nm').textContent='بازیکن ۱';
 newRound();G.mode='play';ui(null);ambience(true);
}
function newRound(){
 const [p,o]=G.fighters;p.reset(3,1);o.reset(4,6);G.roundOver=false;G.endT=0;
 p.inp={f:0,b:0,l:0,r:0,s:0,pL:0,pR:0,pf:0,pb:0,pl:0,pr:0};o.inp={f:0,b:0,l:0,r:0,s:0,pL:0,pR:0,pf:0,pb:0,pl:0,pr:0};
 banner(`راند ${fa(G.round)}<small>${fa(G.wins[0])} : ${fa(G.wins[1])}</small>`,1300);
}
function pauseGame(){if(G.mode!=='play')return;G.mode='pause';ui('pause');}
function resumeGame(){if(G.mode!=='pause')return;G.mode='play';ui(null);}
function toMenu(){G.mode='menu';G.kind=null;clearWorld();hideGame();ambience(false);ui('menu');showMenuScene();HL.forEach(r=>r.forEach(h=>h.visible=false));}
function checkEnd(dt){
 if(G.roundOver){G.endT-=dt;if(G.endT<=0)finishRound();return;}
 if(G.kind==='campaign'){
  const p=G.fighters[0];
  if(p.dead){G.roundOver=true;G.endT=1.6;G.result='lose';}
  else if(G.main.dead){G.roundOver=true;G.endT=1.8;G.result='win';G.enemies.forEach(e=>{if(!e.dead)e.die();});}
 }else{
  const [a,b]=G.fighters;
  if(a.dead||b.dead){G.roundOver=true;G.endT=2;const w=a.dead&&b.dead?-1:(a.dead?1:0);if(w>=0)G.wins[w]++;
   banner(w<0?'مساوی!':(G.kind==='bot'?(w===0?'تو بردی!':'ربات برد'):`بازیکن ${w+1} برد`),1800);}
 }
}
function finishRound(){
 if(G.kind==='campaign'){
  const L=G.level;
  if(G.result==='win'){if(L>=save.level){save.level=Math.min(1000,L+1);persist();}sfx('win');G.mode='over';ui('win');}
  else{sfx('lose');G.mode='over';ui('lose');}
 }else{
  G.round++;
  if(G.wins[0]>=2||G.wins[1]>=2){G.mode='over';const w=G.wins[0]>=2?0:1;sfx(w===0||G.kind==='pvp'?'win':'lose');ui('matchend',w);}
  else newRound();
 }
}

/* ---------- menu scene ---------- */
function showMenuScene(){
 hideMenuScene();
 displayPawn=buildPawn(pcolor());displayPawn.g.scale.setScalar(1.6);displayPawn.g.position.set(-3.2,0,0);displayPawn.g.rotation.y=1.2;scene.add(displayPawn.g);
 dispIdx=dispIdx%6;spawnDisplayEnemy();
}
function spawnDisplayEnemy(){
 if(displayEnemy)scene.remove(displayEnemy.g);
 const t=PIECES[dispIdx%6];displayEnemy=buildPiece(t,ocolor(),{boss:false});displayEnemy.g.scale.setScalar(SCALE[t]*1.1);
 displayEnemy.g.position.set(3.6,0,0);displayEnemy.g.rotation.y=-1.3;scene.add(displayEnemy.g);
}
function hideMenuScene(){if(displayPawn){scene.remove(displayPawn.g);displayPawn=null;}if(displayEnemy){scene.remove(displayEnemy.g);displayEnemy=null;}}


/* ---------- UI screens ---------- */
const ui$=$('#ui');
let levelPage=0;
function ui(name,arg){
 if(!name){ui$.innerHTML='';ui$.style.pointerEvents='none';
  $('#pauseBtn').style.display='';return;}
 ui$.style.pointerEvents='auto';
 const D=DIFFS[save.diff];
 let h='';
 if(name==='menu'){
  h=`<div class="scr"><div class="logo">NoTrO <b>chess</b></div>
  <div class="sub">♟ سربازِ کوچک در برابر ارتش شطرنج ♛</div>
  <div class="by">سازنده: امیرمهدی احمدی ملقب به نوترو</div>
  <button class="btn main" data-a="campaign">🏆 حالت مرحله‌ای — ${fa(1000)} مرحله</button>
  <button class="btn" data-a="bot">🤖 بازی با ربات</button>
  <button class="btn" data-a="pvp">👥 دو نفره تک‌به‌تک</button>
  <div class="row"><button class="btn ${save.color==='white'?'sel':''}" data-a="cw">♙ سفید</button><button class="btn ${save.color==='black'?'sel':''}" data-a="cb">♟ سیاه</button></div>
  <button class="btn" data-a="diff">${D.em} سختی: ${D.name}</button>
  <button class="btn" data-a="about">ℹ️ درباره ما</button></div>`;
 }else if(name==='diff'){
  h=`<div class="scr"><h2>انتخاب سختی</h2>`+DIFFS.map((d,i)=>`<div class="card ${i===save.diff?'sel':''}" data-a="setdiff" data-i="${i}"><span class="em">${d.em}</span><span><div class="nm">${d.name}</div><div class="ds">${d.ds}</div></span></div>`).join('')+
  `<button class="btn" data-a="menu">بازگشت</button></div>`;
 }else if(name==='levels'){
  const per=30,pages=Math.ceil(1000/per);if(levelPage<0)levelPage=0;if(levelPage>=pages)levelPage=pages-1;
  let g='';for(let i=0;i<per;i++){const L=levelPage*per+i+1;if(L>1000)break;const inf=levelInfo(L);const lock=L>save.level;
   g+=`<button class="lv ${lock?'lock':''} ${inf.boss?'boss':''} ${L===save.level?'cur':''}" data-a="play" data-i="${L}" ${lock?'disabled':''}><small>${inf.boss?'♛':GL[inf.type]}</small>${fa(L)}</button>`;}
  h=`<div class="scr"><h2>مرحله‌ها</h2><div class="sub">${D.em} سختی: ${D.name}</div>
  <button class="btn main" data-a="play" data-i="${save.level}">▶ ادامه — مرحله ${fa(save.level)}</button>
  <div class="grid">${g}</div>
  <div class="row"><button class="btn sm" data-a="pp">◀ قبلی</button><button class="btn sm" data-a="pn">بعدی ▶</button></div>
  <button class="btn" data-a="menu">بازگشت</button></div>`;
 }else if(name==='about'){
  h=`<div class="scr"><div class="logo">NoTrO <b>chess</b></div>
  <div class="panel">NoTrO chess یک بازی اکشن شطرنجی برای موبایل است. تو یک سرباز کوچک هستی و باید در یک زمین خالی، تک‌به‌تک با مهره‌های شطرنج بجنگی؛ سرباز، اسب، فیل، رخ، وزیر و شاه. هر مهره به سبک خودش حمله می‌کند و وزیر باس فایت بازی است!<br>
  الهام‌گرفته از بازی Pawned Souls.<br><br>
  <b style="color:var(--acc)">سازنده اصلی: امیرمهدی احمدی ملقب به نوترو</b></div>
  <button class="btn" data-a="menu">بازگشت</button></div>`;
 }else if(name==='pause'){
  h=`<div class="scr" style="background:var(--panel);padding:20px;border-radius:14px;max-width:340px"><h2>توقف</h2>
  <button class="btn main" data-a="resume">▶ ادامه</button><button class="btn" data-a="restart">↻ شروع دوباره</button><button class="btn" data-a="menu">🏠 بازگشت به منوی اصلی</button></div>`;
 }else if(name==='win'){
  const inf=G.info;const last=G.level>=1000;
  h=`<div class="scr" style="background:var(--panel);padding:20px;border-radius:14px;max-width:340px"><h2>🏆 پیروزی!</h2>
  <div>${inf.boss?'وزیر شکست خورد!':PN[inf.type]+' شکست خورد.'}</div>${last?'<div style="color:var(--acc)">تو قهرمان NoTrO chess شدی! 👑</div>':''}
  ${last?'':`<button class="btn main" data-a="play" data-i="${G.level+1}">مرحله بعد (${fa(G.level+1)})</button>`}
  <button class="btn" data-a="play" data-i="${G.level}">دوباره همین مرحله</button><button class="btn" data-a="menu">🏠 منوی اصلی</button></div>`;
 }else if(name==='lose'){
  h=`<div class="scr" style="background:var(--panel);padding:20px;border-radius:14px;max-width:340px"><h2>💀 شکست خوردی</h2>
  <div class="sub">مثل شطرنج فکر کن: خونه‌های قرمز خطرناکن، ازشون برو بیرون. ضربه‌ی تو فقط قطریه!</div>
  <button class="btn main" data-a="play" data-i="${G.level}">↻ تلاش دوباره</button><button class="btn" data-a="menu">🏠 منوی اصلی</button></div>`;
 }else if(name==='matchend'){
  const t=G.kind==='bot'?(arg===0?'🏆 تو بردی!':'🤖 ربات برد'):`🏆 بازیکن ${arg+1} برنده شد!`;
  h=`<div class="scr" style="background:var(--panel);padding:20px;border-radius:14px;max-width:340px"><h2>${t}</h2><div>${fa(G.wins[0])} : ${fa(G.wins[1])}</div>
  <button class="btn main" data-a="again">↻ دوباره</button><button class="btn" data-a="menu">🏠 منوی اصلی</button></div>`;
 }
 ui$.innerHTML=h;
 $('#pauseBtn').style.display='none';
}
ui$.addEventListener('click',e=>{
 const t=e.target.closest('[data-a]');if(!t)return;audioInit();sfx('ui');
 const a=t.dataset.a,i=+t.dataset.i;
 switch(a){
  case 'campaign':levelPage=Math.floor((save.level-1)/30);ui('levels');break;
  case 'bot':startBot();break;case 'pvp':startPvp();break;
  case 'cw':save.color='white';persist();G.pcolor='white';showMenuScene();ui('menu');break;
  case 'cb':save.color='black';persist();G.pcolor='black';showMenuScene();ui('menu');break;
  case 'diff':ui('diff');break;
  case 'setdiff':save.diff=i;persist();ui('diff');break;
  case 'about':ui('about');break;
  case 'menu':toMenu();break;
  case 'play':startCampaign(i);break;
  case 'pp':levelPage--;ui('levels');break;
  case 'pn':levelPage++;ui('levels');break;
  case 'resume':resumeGame();break;
  case 'restart':if(G.kind==='campaign')startCampaign(G.level);else if(G.kind==='bot')startBot();else startPvp();break;
  case 'again':if(G.kind==='bot')startBot();else startPvp();break;
 }
});
$('#pauseBtn').addEventListener('click',()=>{audioInit();pauseGame();});


/* ---------- render ---------- */
const camState=[{},{}];
function followCam(cam,i,dt){
 const f=G.fighters[i],st=camState[i];
 const ty=Math.atan2(f.fx,f.fz);
 if(st.yaw===undefined){st.yaw=ty;st.x=f.x;st.z=f.z;}
 st.yaw+=angDiff(st.yaw,ty)*Math.min(1,dt*3.2);
 st.x+=(f.x-st.x)*Math.min(1,dt*8);st.z+=(f.z-st.z)*Math.min(1,dt*8);
 const sn=Math.sin(st.yaw),cs=Math.cos(st.yaw),sh=G.shake;
 cam.position.set(st.x-sn*9+rnd(-1,1)*sh*.6,11+rnd(-1,1)*sh*.4,st.z-cs*9+rnd(-1,1)*sh*.6);
 cam.up.set(0,1,0);cam.lookAt(st.x+sn*4.5,.6,st.z+cs*4.5);
}
function renderAll(dt){
 const W=VW,H=VH;
 renderer.setScissorTest(true);
 if(G.mode==='menu'||!G.fighters.length){
  dispT+=dt;const a=dispT*.25;
  menuCam.aspect=W/H;menuCam.updateProjectionMatrix();
  menuCam.position.set(Math.sin(a)*3,4.6,-14+Math.cos(a)*1.5);menuCam.lookAt(0,2.4,0);
  renderer.setViewport(0,0,W,H);renderer.setScissor(0,0,W,H);renderer.render(scene,menuCam);
  return;
 }
 if(G.kind==='pvp'){
  const h=Math.floor(H/2);
  cams.forEach(c=>{c.aspect=W/h;c.updateProjectionMatrix();});
  followCam(cams[0],0,dt);followCam(cams[1],1,dt);
  renderer.setViewport(0,0,W,h);renderer.setScissor(0,0,W,h);renderer.render(scene,cams[0]);
  renderer.setViewport(0,h,W,H-h);renderer.setScissor(0,h,W,H-h);renderer.render(scene,cams[1]);
 }else{
  cams[0].aspect=W/H;cams[0].updateProjectionMatrix();followCam(cams[0],0,dt);
  renderer.setViewport(0,0,W,H);renderer.setScissor(0,0,W,H);renderer.render(scene,cams[0]);
 }
}
let last=nowS();
function frame(){
 requestAnimationFrame(frame);
 const t=nowS();let dt=Math.min(.05,t-last);last=t;G.time+=dt;
 if(G.mode==='play'||G.mode==='over'){
  if(G.hitstop>0){G.hitstop-=dt;dt*=.12;}
  const fs=G.fighters;
  if(G.mode==='play'&&G.kind==='bot'&&!fs[1].dead&&!fs[0].dead)botThink(fs[1],fs[0],dt);
  fs.forEach((f,i)=>{const foes=G.kind==='campaign'?G.enemies:[fs[1-i]];f.update(dt,foes);});
  G.enemies.forEach(e=>e.update(dt));
  fs.forEach(f=>f.animate(dt));G.enemies.forEach(e=>e.animate(dt));
  if(G.mode==='play'||G.roundOver)checkEnd(dt);
  hudUpdate();
 }
 if(G.mode==='menu'&&displayPawn){
  displayPawn.g.position.y=Math.sin(G.time*2)*.05;displayPawn.armL.rotation.y=.25+Math.sin(G.time*2)*.05;
  displayPawn.g.rotation.y=1.2+Math.sin(G.time*.6)*.2;
  if(displayEnemy){displayEnemy.g.rotation.y=-1.3+Math.sin(G.time*.5)*.25;
   if(Math.floor(G.time/4)!==dispIdx){dispIdx=Math.floor(G.time/4);spawnDisplayEnemy();}}
 }
 if(G.mode!=='pause')updateHL(dt);
 G.shake*=Math.max(0,1-9*dt);if(G.shake<.01)G.shake=0;
 updateParts(dt);
 fire1.intensity=1.3+Math.sin(G.time*13)*.2;fire2.intensity=1.3+Math.sin(G.time*11+1)*.2;
 dust.rotation.y+=dt*.02;dust.position.y=Math.sin(G.time*.3)*.4;
 renderAll(dt);
}
showMenuScene();ui('menu');
frame();
window.__G=G;window.__start=startCampaign;
