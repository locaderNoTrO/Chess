import base64,os,zipfile,io
B=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+'/'
css=open(B+'src/style.css').read();body=open(B+'src/body.html').read();js=open(B+'src/game.js').read()
# --- APK web file
idx=f'<!doctype html>\n<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>NoTrO chess</title><style>{css}</style></head><body>\n{body}\n<script src="lib/three.min.js"></script>\n<script>\n{js}\n</script></body></html>'
open(B+'www/index.html','w').write(idx)
# --- zip
zb=io.BytesIO()
with zipfile.ZipFile(zb,'w',zipfile.ZIP_DEFLATED) as z:
    for root,_,files in os.walk(B):
        if '/src' in root or '.zip' in root: pass
        for f in files:
            p=os.path.join(root,f)
            if p.endswith('.zip') or f=='lib' or 'test_stub' in f or 'run_test' in f or '/artifact' in p:continue
            z.write(p,'NoTrOChess/'+os.path.relpath(p,B))
open('/home/claude/NoTrOChess.zip','wb').write(zb.getvalue())
b64=base64.b64encode(zb.getvalue()).decode()
# --- artifact page (fragment)
art=f'''<title>NoTrO chess</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700;900&display=swap">
<style>{css}
html,body{{background:#000}}
#dl{{position:fixed;left:max(8px,env(safe-area-inset-left));bottom:8px;z-index:20;font-size:11px;padding:6px 9px;border-radius:8px;border:1px solid #666;background:rgba(0,0,0,.7);color:#e9e4d4;font-family:inherit;cursor:pointer;touch-action:manipulation}}
</style>
{body}
<button id="dl" class="hidden">⬇ دانلود زیپ پروژه</button>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script>
{js}
</script>
<script>
(async()=>{{try{{const d=await claude.use("downloads");if(!d)return;const b=document.getElementById('dl');b.classList.remove('hidden');
b.onclick=async()=>{{try{{const bin=atob("{b64}");const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
await d.save({{filename:'NoTrOChess.zip',data:u}});}}catch(e){{}}}};}}catch(e){{}}}})();
</script>'''
open('/home/claude/notro-chess-page.html','w').write(art)
print(len(zb.getvalue()),len(art))
