import re, glob, sys
# 1) lock portrait in the manifest
mf = 'android/app/src/main/AndroidManifest.xml'
s = open(mf, encoding='utf-8').read()
if 'screenOrientation' not in s:
    s = s.replace('<activity', '<activity\n            android:screenOrientation="portrait"', 1)
open(mf, 'w', encoding='utf-8').write(s)
# 2) fullscreen immersive + keep screen on
for f in glob.glob('android/app/src/main/java/**/MainActivity.java', recursive=True):
    j = open(f, encoding='utf-8').read()
    if 'NoTrOPatched' in j:
        continue
    j = re.sub(r'import com\.getcapacitor\.BridgeActivity;',
               'import com.getcapacitor.BridgeActivity;\nimport android.os.Bundle;\nimport android.view.View;\nimport android.view.WindowManager;', j)
    body = '''
    // NoTrOPatched
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideBars();
    }
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }
    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
'''
    j = re.sub(r'(public class MainActivity extends BridgeActivity\s*\{)', r'\1' + body, j)
    open(f, 'w', encoding='utf-8').write(j)
print('patched')
